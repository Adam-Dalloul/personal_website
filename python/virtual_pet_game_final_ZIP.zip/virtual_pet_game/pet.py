import tkinter, os
from tkinter.ttk import Progressbar

#Global Variables for Pet State
sleepiness_value = 10
food_value = 15
social_status_value = 20

def update_ui():
    # Update Progress Bar & Label
    sleepiness_level_meter["value"] = sleepiness_value
    sleepiness_level_text.config(text="Sleepiness Level: " + str(sleepiness_value))

    food_meter["value"] = food_value
    food_level_text.config(text="Food Level: " + str(food_value))

    social_status_meter["value"] = social_status_value
    social_status_text.config(text="Social Level: " + str(social_status_value))

    # Sleepiness Level Low, Food Level Low, Social Status Low = Energized but sad (First Status)
    # Sleepines Level High, Food level High, Social Status High = Sleepy but relieved (Second Status)
    # Sleepiness Level Low, Food Level High, Social Status Low = Fuffilled (Third Status)
    # Sleepiness Level High, Food Level Low, Social Status High = Depressed (Fourth Status)
    # Sleepiness Level Low, Food Level High, Social Status High = Overly joyed and happy (Fifth Status)
    # Sleepiness Level High, Food Level Low, Social Status High = I am sleepy and famished but content (Sixth Option)
    # Slepiness Level Low, Food Level Low, Social Status High = I am awake and hungry but pleased (Seventh Option)
    # Sleepiness Level High, Food Level High, Social Status Low = I am drowsy and full but lonely (Eigth Option)
    
    # Low = 0-20
    # High = 21-50
    sleepiness_level_low = sleepiness_value >= 0 and sleepiness_value <= 20
    sleepiness_level_high = sleepiness_value >= 21 and sleepiness_value <=50

    food_level_low = food_value >= 0 and food_value <= 20
    food_level_high = food_value >= 21 and food_value <= 50

    social_status_low = social_status_value >=0 and social_status_value <= 20
    social_status_high = social_status_value >= 21 and social_status_value <=50

    # First Status
    if sleepiness_level_low == True and food_level_low == True and social_status_low == True:
        pet_img_label.config(image=normal_zebra_image_small)
        pet_condition_label.config(text="I am energized but sad ⚡")

    #Third Status
    elif sleepiness_level_low == True and food_level_high == True and social_status_low == True:
        pet_condition_label.config(text="I am fulfilled with life 😐")
        pet_img_label.config(image=happy_zebra_image_small)

    #Fourth Status
    elif sleepiness_level_high == True and food_level_low == True and social_status_low == True: 
        pet_condition_label.config(text="I am extremely depressed 😭")
        pet_img_label.config(image=sad_zebra_img_small)
    
    #Fifth Status
    elif sleepiness_level_low == True and food_level_high == True and social_status_high == True:
        pet_condition_label.config(text="I am overly joyed and happy 😁")
        pet_img_label.config(image=happy_zebra_image_small)
        
    #Sixth Status
    elif sleepiness_level_high == True and food_level_low == True and social_status_high == True:
        pet_condition_label.config(text="I am sleepy and famished but content 😫💤")
        pet_img_label.config(image=sleepy_zebra_image_small)
        
    #Seventh Status
    elif sleepiness_level_low == True and food_level_low == True and social_status_high == True:
        pet_condition_label.config(text="I am hungry but pleased and awake 😌")
        pet_img_label.config(image=normal_zebra_image_small)
                
    #Eigth Status
    elif sleepiness_level_high == True and food_level_high == True and social_status_low == True:
        pet_condition_label.config(text="I am drowsy and lonely but full 😋")
        pet_img_label.config(image=sleepy_zebra_image_small)

    #Second Status
    else:
        pet_img_label.config(image=sleepy_zebra_image_small)
        pet_condition_label.config(text="I am sleepy, yet relieved 😴")

    
#Slap pet function
def slap_btn_click():
    global sleepiness_value
    if sleepiness_value <= 50 and sleepiness_value >= 5:
        sleepiness_value -= 5
    
    update_ui()
def get_leaves_btn_click():
    global food_value
    if food_value <=45:
        food_value +=5
        
    update_ui()

def get_friends_btn_click():
    global social_status_value
    if social_status_value <= 45:
        social_status_value += 5
    
    update_ui()

def autoupdate_pet_stats():
    global sleepiness_value
    if sleepiness_value >= 0 and sleepiness_value <= 45:
        sleepiness_value += 5
    print("Sleepiness Level: " + str(sleepiness_value))

    global food_value
    if food_value > 0:
        food_value -= 5
    print("Food Level: " + str(food_value))

    global social_status_value
    if social_status_value > 0:
        social_status_value -= 5
    print("Social Level: " + str(social_status_value))

#Put all timer changes in here
def master_timer():
    #Decrease the pet states
    autoupdate_pet_stats()
    #Update UI
    update_ui()
    #Repeat every 2 seconds
    root.after(2000, master_timer)

#Create the Main Window
root = tkinter.Tk()
root.title("Virtual Zebra Pet")
root.geometry("300x450")
root.configure(bg='pink')

#Add the starting Pet Image
root_path = os.path.dirname(__file__)
normal_zebra_image = tkinter.PhotoImage(file=root_path + "\\Images\\Zebra.png")
sad_pet_img = tkinter.PhotoImage(file=root_path + "\\Images\\SadZebra.png")
happy_zebra_image = tkinter.PhotoImage(file=root_path + "\\Images\\ZebraImageHappy.png")
sleepy_zebra_image = tkinter.PhotoImage(file=root_path + "\\Images\\ZebraImageSleepy.png")

normal_zebra_image_small = normal_zebra_image.subsample(2,2)
sad_zebra_img_small = sad_pet_img.subsample(2,2)
happy_zebra_image_small = happy_zebra_image.subsample(2,2)
sleepy_zebra_image_small = sleepy_zebra_image.subsample(1,1)
pet_img_label = tkinter.Label(image=sad_zebra_img_small, height=300, width = 300)

pet_img_label.grid(row=0, column=1, columnspan=3)


#Add the label for the pet condition
pet_condition_label = tkinter.Label(root, text="I'm hungry")
# pet_condition_label.pack()
pet_condition_label.grid(row=1, column=1, columnspan=3)

#Add a button to slap the pet
slap_buton = tkinter.Button(root, text="Slap Me", command=slap_btn_click)
# feed_buton.pack()
slap_buton.grid(row=2, column=1)

#Add button to get leaves for the Zebra
get_leaves_button = tkinter.Button(root, text="Get Me Leaves", command=get_leaves_btn_click)
get_leaves_button.grid(row=2, column=2)

#Add button to get the Zebra some friends
get_friends_button = tkinter.Button(root, text="Get Me Friends", command=get_friends_btn_click)
get_friends_button.grid(row=2, column=3)

#Food Progress Bar
food_meter = Progressbar(root, orient= tkinter.HORIZONTAL, length=100, max=50, mode="determinate")
food_meter["value"] = food_value
food_meter.grid(row=3, column=2)

#Food Progress Bar Text
food_level_text = tkinter.Label(text="Food Level: " + str(food_value))
food_level_text.grid(row=4, column=2)

#Sleepiness Progress Bar
sleepiness_level_meter = Progressbar(root, orient= tkinter.HORIZONTAL, length=100, max=50, mode = "determinate")
sleepiness_level_meter["value"] = sleepiness_value
sleepiness_level_meter.grid(row=3, column=1)

#Sleepiness Progress Bar Text
sleepiness_level_text = tkinter.Label(text="Sleepiness Level: " + str(sleepiness_value))
sleepiness_level_text.grid(row=4, column=1)

#Friends progress bar
social_status_meter = Progressbar(root, orient= tkinter.HORIZONTAL, length=100, max=50, mode="determinate")
social_status_meter["value"] = social_status_value
social_status_meter.grid(row=3, column=3)

#Social Status Progres bar text 
social_status_text = tkinter.Label(text="Social Level: " + str(social_status_value))
social_status_text.grid(row=4, column=3)

#Call Master Timer
master_timer()

#Keep the Windows Up
root.mainloop()