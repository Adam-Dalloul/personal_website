import random
#The Function
def magic_algorithm(share_count, like_count, find_top_comment, comments):
    rank = 0
    if share_count >= 35000 and share_count <= 45000 and like_count >= 50000 and like_count <= 75000:
        if find_top_comment != -1 and comments >= 50000:
            rank=random.randint(11,20)
        elif comments >= 20000 and find_top_comment == -1:
            rank=random.randint(21,30)
        else:
            rank=random.randint(31,40)
    elif find_top_comment != -1 and comments >= 100000 and share_count >= 55000 and like_count >= 700000:
        rank=random.randint(1,10)
    else:
        if find_top_comment == -1 and like_count <=10000:
            rank=random.randint(81,100)
        elif comments >= 25000 and like_count >= 35000:
            rank=random.randint(41,60)
        else:
            rank=random.randint(61,80)     
    return rank

#Ask the user for share count
share_count = int(input("What is the share count of your TikTok video? "))

#Ask the user for like count
like_count = int(input("What is the like count of your TikTok video? "))

#Asking the user for the top comment on the video
top_comment = input("What is the top comment on your TikTok video? ")
find_top_comment = top_comment.find("cool")

#Asking the user for number of comments on the video
comments = int(input("How many comments does your TikTok Video have? "))

#Output the tiktok ranking
end_rank =  magic_algorithm(share_count, like_count, find_top_comment, comments)
print("Your TikTok video ranking is " + "#" + str(end_rank))