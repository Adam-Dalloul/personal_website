import tkinter, tkinter.ttk, os, pygame

#Grapic Parameters
CANVAS_WIDTH=500
CANVAS_HEIGHT=700
TIMER_REFRESH = 25

#Beach Ball Movement
image_x_move = 3
image_y_move = 3

#Game Parameters
paddle_speed = 5
score_green = 0
score_blue = 0

#Game Mode Types
game_mode_solo = False
game_mode_duo = True

#Game State
game_running = True

#Intilize pygame
pygame.init()

#Ending the Game
def end_game():
    global game_running
    game_running = False
    canvas.create_text(CANVAS_WIDTH/2, CANVAS_HEIGHT/2, text="GAME OVER")
    if score_green > score_blue:
        canvas.create_text(CANVAS_WIDTH/2, CANVAS_HEIGHT/1.9, fill="green", text="Green Won!")
    elif score_blue > score_green:
        canvas.create_text(CANVAS_WIDTH/2, CANVAS_HEIGHT/1.9, fill="blue", text="Blue Won!")
    quit_game_button = tkinter.Button(main, text="Quit", command=quit_game)
    quit_game_button.place(x=230,y=385)
    end_game_sound()

#Collision
def collision_green(left, top, right, bottom):
    # Check to see if ball collided with paddle
    overlap_result_green = canvas.find_overlapping(left, right, top, bottom)
    
    # Is my paddle in the overlap result?
    # return true if yes, else false
    if greenPaddle in overlap_result_green:
        return True;
    else:
        return False;

def collision_blue(left, top, right, bottom):
    # Check to see if ball collided with paddle
    overlap_result_blue = canvas.find_overlapping(top, bottom, left, right)

    # Is my paddle in the overlap result?
    # return true if yes, else false
    if bluePaddle in overlap_result_blue:
        return True;
    else:
        return False;

#Move the Green Paddle with arrow keys
def move_paddle_arrows(event):
    if game_running:
        key_symbol = event.keysym
        
        # Where is the paddle now
        pos = canvas.coords(greenPaddle)
        left = pos[0]
        right = left + greenPadle_width
        
        #move paddle left
        if key_symbol == "Left" and left > 0:
            canvas.move(greenPaddle,-paddle_speed, 0)
        #move paddle right
        elif key_symbol == "Right" and right <= CANVAS_WIDTH-44:
            canvas.move(greenPaddle,paddle_speed, 0)

#Move the Blue Paddle with WASD keys:
def move_paddle_WASD(event):
    if game_running and game_mode_duo:
        key_symbol = event.keysym
        
        # Where is the paddle now
        pos = canvas.coords(bluePaddle)
        left = pos[0]
        right = left + bluePaddle_width
        
        #move paddle left
        if key_symbol == "a" and left > 0:
            canvas.move(bluePaddle,-paddle_speed, 0)
        #move paddle right
        elif key_symbol == "d" and right <= CANVAS_WIDTH-2:
            canvas.move(bluePaddle,paddle_speed, 0)

#Move the Beach Ball
def draw_image():
    global image_y_move
    global image_x_move
    global score_green, score_blue

    canvas.move(beachBall, image_x_move, image_y_move)

    # What is the current location of the beach ball?
    pos = canvas.coords(beachBall)
    top_y = pos[1]
    left = pos[0]
    right = left + beachBall_width
    bottom_y = top_y + beachBall_height

    # Time to bounce?
    # Did it hit the bottom or top (y value)?
    if bottom_y >= CANVAS_HEIGHT-120: 
        image_y_move = -image_y_move
        score_blue +=1
        score_blue_label.config(text="Blue Score: " + str(score_blue))
        wall_bounce()
    elif top_y <= 25:
        image_y_move = -image_y_move
        score_green += 1
        score_green_label.config(text="Green Score: " + str(score_green))
        wall_bounce()
    # Did it hit the top or bottom (x value)?
    elif left <= 1 or right >= CANVAS_WIDTH-8:
        image_x_move = -image_x_move
        wall_bounce()
    # Did the ball collide with the paddle? If so bounce off
    if collision_green(left, right, top_y, bottom_y):
        image_y_move = -image_y_move
        bounce()
    
    if collision_blue(left, right, top_y, bottom_y):
        image_y_move = -image_y_move
        bounce()

#Exit/Quit Game
def quit_game():
    quit()

root_path = os.path.dirname(__file__)
#Background Music
def intro_sound():
    pygame.mixer.music.load(root_path+"\\Audios\\IntroSound.mp3")    
    pygame.mixer.music.play(loops=0)    
    pygame.mixer.music.set_volume(0.01)
#Bounce Sound Effect
def bounce():
    pygame.mixer.music.load(root_path+"\\Audios\\Bounce.mp3")    
    pygame.mixer.music.play(loops=0)       
#Bounce Off Wall Sound Effect
def wall_bounce():
    pygame.mixer.music.load(root_path+"\\Audios\\WallBounce.mp3")    
    pygame.mixer.music.play(loops=0)        
#End Game Sound
def end_game_sound():
    pygame.mixer.music.load(root_path+"\\Audios\\GameOver.mp3")
    pygame.mixer.music.play(loops=0)
#Changing the ball speed
def change_ball_speed_1():
    global image_x_move,image_y_move
    image_x_move = 3
    image_y_move = 3
    pygame.mixer.music.load(root_path+"\\Audios\\GameClick.mp3")
    pygame.mixer.music.play(loops=0)
def change_ball_speed_1_5():
    global image_x_move,image_y_move
    image_x_move = 4.5
    image_y_move = 4.5
    pygame.mixer.music.load(root_path+"\\Audios\\GameClick.mp3")
    pygame.mixer.music.play(loops=0)
def change_ball_speed_2_5():
    global image_x_move,image_y_move
    image_x_move = 7.5
    image_y_move = 7.5
    pygame.mixer.music.load(root_path+"\\Audios\\GameClick.mp3")
    pygame.mixer.music.play(loops=0)

#Make the Computer Player
def computer_player():
    # What is the current location of the beach ball?
    pos = canvas.coords(beachBall)
    top_y = pos[1]
    left = pos[0]
    
    # Where is the paddle now
    pos = canvas.coords(bluePaddle)
    left_blue = pos[0]
    right_blue = left_blue + bluePaddle_width
    
    # Time to bounce?
    # Did it hit the bottom or top (y value)?
    if left_blue > 0 and left < 50:
        #move paddle left
        canvas.move(bluePaddle,-paddle_speed, 0)
    elif top_y < 130 and right_blue <= CANVAS_WIDTH-2:
        #move paddle right
        canvas.move(bluePaddle,paddle_speed, 0)
    
#Select the game mode
def game_mode_select_solo():
    global game_mode_solo, game_mode_duo
    #Set gamemode to solo
    game_mode_solo = True
    game_mode_duo = False
    pygame.mixer.music.load(root_path+"\\Audios\\GameClick.mp3")
    pygame.mixer.music.play(loops=0)
def game_mode_select_duo():
    global game_mode_solo, game_mode_duo
    #Set gamemode to duo
    game_mode_duo = True
    game_mode_solo = False
    pygame.mixer.music.load(root_path+"\\Audios\\GameClick.mp3")
    pygame.mixer.music.play(loops=0)
def check_game_mode():
    if game_mode_solo:
        #Add the label for the Game Mode
        current_game_mode_label.config(text="Game Mode: Solo")
    elif game_mode_duo:
        #Add the label for the Game Mode
        current_game_mode_label.config(text="Game Mode: Local 2 Player")

#Animation Timer
def master_timer():
    # Draw/move ball
    draw_image()
    if game_mode_solo:
        computer_player()
    #Update Current Game Mode Text
    check_game_mode()
    # tkinter procecssing
    main.update_idletasks()
    main.update()
    if game_running:
        main.after(TIMER_REFRESH, master_timer)
    #End game at 10 points
    if score_green == 10 or score_blue == 10:
        end_game()
        

#Create Window
main = tkinter.Tk()
main.title("Advanced Pong")
#Lock Window Size (block resizing window)
main.resizable(0,0)
#Draw the Canvas
canvas = tkinter.Canvas(main, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bd=0, highlightthickness=0)
canvas.grid()


#Add Beach Ball Image
beachBallImage = tkinter.PhotoImage(file=root_path + "\\Images\\BeachBallPng.png")
beachBallImage_small = beachBallImage.subsample(35,35)
beachBall = canvas.create_image(0,0,anchor=tkinter.NW,image=beachBallImage_small)
#Get Demensions of my image
beachBall_height = beachBallImage_small.height()
beachBall_width = beachBallImage_small.width()
#Move Ball Position
canvas.move(beachBall, CANVAS_WIDTH/2.2, CANVAS_HEIGHT/3)

#Add Green Paddle
greenPaddleImage = tkinter.PhotoImage(file=root_path + "\\Images\\rectangleGreen.png")
greenPaddleImage_small = greenPaddleImage.subsample(10,20)
greenPaddle = canvas.create_image(0,0,anchor=tkinter.NW,image=greenPaddleImage_small)
#Get Dimensions of image
greenPadle_height = beachBallImage_small.height()
greenPadle_width = beachBallImage_small.width()
#Move Paddle Position
canvas.move(greenPaddle, CANVAS_WIDTH/2.2, CANVAS_HEIGHT/1.4)

#Add Blue Paddle
bluePaddleImage = tkinter.PhotoImage(file=root_path + "\\Images\\BluePaddle.png")
bluePaddleImage_small = bluePaddleImage.subsample(7,5)
bluePaddle = canvas.create_image(0,0,anchor=tkinter.NW,image=bluePaddleImage_small)
#Get Dimensions of image
bluePaddle_height = bluePaddleImage_small.height()
bluePaddle_width = bluePaddleImage_small.width()
#Move Paddle Position
canvas.move(bluePaddle, CANVAS_WIDTH/2.2, CANVAS_HEIGHT/8)

# #Add key bindings for ARROW keys
canvas.bind_all("<KeyPress-Right>", move_paddle_arrows)
canvas.bind_all("<KeyPress-Left>", move_paddle_arrows)
# #Add key bindings for AD keys
canvas.bind_all("<KeyPress-a>", move_paddle_WASD)
canvas.bind_all("<KeyPress-d>", move_paddle_WASD)

#Add the label for the Green paddle Score
score_green_label = tkinter.Label(main, text="Green Score: " + str(score_green))
score_green_label.place(x=2.5, y=7)

#Add the label for the Blue paddle Score
score_blue_label = tkinter.Label(main, text="Blue Score: " + str(score_blue))
score_blue_label.place(x=420, y=7)

#Add the label for the current Game Mode
current_game_mode_label = tkinter.Label(main, text="Game Mode: Local 2 Player")
current_game_mode_label.place(x=190, y=7)

#Add the label for Ball Speed Level
ball_speed_label = tkinter.Label(main, text="Speed:")
ball_speed_label.place(x=10, y=650)

#Add a button to change ball speed back to normal at 1x speed
ball_speed_1_point_button = tkinter.Button(main, text="1x", command=change_ball_speed_1)
ball_speed_1_point_button.place(x=10, y=670)

#Add a button to change ball speed to 1.5x faster
ball_speed_1_point_5_button = tkinter.Button(main, text="1.5x", command=change_ball_speed_1_5)
ball_speed_1_point_5_button.place(x=40, y=670)

#Add a button to change ball speed to 2.5x faster
ball_speed_2_point_5_button = tkinter.Button(main, text="2.5x", command=change_ball_speed_2_5)
ball_speed_2_point_5_button.place(x=80, y=670)

#Add the label for Game Mode
game_mode_label = tkinter.Label(main, text="Mode:")
game_mode_label.place(x=10, y=600)

#Add a button to select Solo game mode
solo_game_button = tkinter.Button(main, text="Solo", command=game_mode_select_solo)
solo_game_button.place(x=10, y=620)

#Add a button to select Local 2 player game mode
two_player_game_button = tkinter.Button(main, text="Local 2 players", command=game_mode_select_duo)
two_player_game_button.place(x=50, y=620)

#Add instructions to the game
canvas.create_text(CANVAS_WIDTH/1.5, CANVAS_HEIGHT/1.07, text="""
Instructions:
Main Goal - Make sure the ball doesn't hit the horizontal wall
and make sure the ball doesn't hit the corner of the paddles
or you will face the consequences! First to 10 wins.
Solo - Use arrow keys to control your paddle.
Two Player - Use AD and arrow keys. 
""") 

#Call Master Timer
master_timer()

#Play the Background music
intro_sound()

#Keep Window Up
main.mainloop()