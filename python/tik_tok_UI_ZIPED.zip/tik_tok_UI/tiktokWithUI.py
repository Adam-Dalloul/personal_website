import random
import tkinter, os, webbrowser

#The Function
def magic_algorithm(share_count, like_count, find_top_comment, comments):
    find_top_comment = find_top_comment.find("cool")
    rank = 0
    if share_count >= 35000 and share_count <= 45000 and like_count >= 50000 and like_count <= 75000:
        if find_top_comment != -1 and comments >= 50000:
            rank=random.randint(11,20)
        elif comments >= 20000 and find_top_comment == -1:
            rank=random.randint(21,30)
        else:
            rank=random.randint(31,40)
    elif find_top_comment != -1 and comments >= 100000 and share_count >= 55000 and like_count >= 700000:
        rank=random.randint(1,10)
    else:
        if find_top_comment == -1 and like_count <=10000:
            rank=random.randint(81,100)
        elif comments >= 25000 and like_count >= 35000:
            rank=random.randint(41,60)
        else:
            rank=random.randint(61,80)     
    return rank

def calculate_ranking():
    # Read in the entry values
    shares = int(shares_entry.get())
    likes = int(likes_entry.get())
    top_comment = top_comment_entry.get()
    comments = int(comments_entry.get())   

    # Pass values into algorithm
    rank = magic_algorithm(shares, likes, top_comment, comments)
    # Print result to result label
    result_label.config(text="Your TikTok video ranking is: #" + str(rank))
    
#Create TIkTok UI with Tkinter
root = tkinter.Tk()
root.title("TikTok Algorithm Ranking")
root.geometry("400x600")

#Adding widgets - Likes, Shares, Top comment, comments
#Number of Likes
likes_label = tkinter.Label(root, text="Number of Likes on Video:")
likes_label.pack()
likes_entry = tkinter.Entry(root)
likes_entry.pack()

#Number of Shares
shares_label = tkinter.Label(root, text="Number of Shares on Video:")
shares_label.pack()
shares_entry = tkinter.Entry(root)
shares_entry.pack()

#Number of Comments
comments_labels = tkinter.Label(root, text="Number of Comments on Video:")
comments_labels.pack()
comments_entry = tkinter.Entry(root)
comments_entry.pack()

#Top Comment
top_comment_label = tkinter.Label(root, text="Top Comment on Video:")
top_comment_label.pack()
top_comment_entry = tkinter.Entry(root)
top_comment_entry.pack()

#Image
img_path = os.path.dirname(__file__) + "\\Images\\TikTokDog.png"
dog_image = tkinter.PhotoImage(file=img_path)

#Resize Image
dog_image_small = dog_image.subsample(4,4)

#Display Image
image_label = tkinter.Label(root, image=dog_image_small)
image_label.pack()

#Rank Button
rank_buton = tkinter.Button(root, text="Get Ranking", command=calculate_ranking)
rank_buton.pack()

#Result
result_label = tkinter.Label(root, text = "Your TikTok Video ranking is: #")
result_label.pack()

#Keep the UI runnning
root.mainloop()


#-----------------COMMAND LINE VERSION---------------------
# #Ask the user for share count
# share_count = int(input("What is the share count of your TikTok video? "))

# #Ask the user for like count
# like_count = int(input("What is the like count of your TikTok video? "))

# #Asking the user for the top comment on the video
# top_comment = input("What is the top comment on your TikTok video? ")
# find_top_comment = top_comment.find("cool")

# #Asking the user for number of comments on the video
# comments = int(input("How many comments does your TikTok Video have? "))

#Output the tiktok ranking
# end_rank =  magic_algorithm(share_count, like_count, find_top_comment, comments)
# print("Your TikTok video ranking is " + "#" + str(end_rank))