name = "Adam D"
num = 8

print("Hello " + name)
print("Hello", name)
print(f"Hello {name}")
print("Your favorite number is:", num)
print(f"Your favorite number is: {num}")
print("Your favorite number is: " + str(num))

#Math
num2 = 13
num3 = "15"

result = num2 + num
print(result)
result = (num2 + num) * num2
print(result)
print((num + num2) * num2)

print(num*num2/int(num3))

#Floats

num4 = 5.5555
num5 = "4.4444"

results1 = (num4 + float(num5))

print(results1)

#Invalid variable names)

#1 = 3
#(AD = 4
#.,[adam = 5
#4yash = 4
#4 = 5
