print("Hello World")

#Printing with Hello "World"
print('Hello "World"')
print("Hello \"World\"")

#Poem Challenge

print(''' "and who
                may I ask
                            paid the gorilla  
                                to stay asleep?"
the race was over almost as soon
        as he entered the room
        he lay down in a bathtub
        full of shaved ice
        and commenced
to sing the well-known ditty
                            who?
                    I say
                        hoop!
aid the girl's 
                            Ellah
\x1B[3m(Tuesday: a sleep...)\x1B[0m
'''
)

#Peom Challenge #2

# print('''
#                 Dusk
#             Above the
#         water hang the 
#                     loud
#                    flies
#                   Here
#                  O so
#                 gray
#                then
              
# ''')