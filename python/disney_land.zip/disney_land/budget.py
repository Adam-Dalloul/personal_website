#Single Costs (rows)
flight_ticket_cost = 200
hotel_perday_cost = 100
park_ticket_perday_cost = 76
merch_cost = 100
meals_cost = 12
vechile_rent_cost_perday = 200
line_skips_cost_each_time = 15
parking_perday_cost = 35

#User Input (collumns)
num_people = int(input("How many people are going on this trip? "))
num_days = int(input("How long is the trip? (# of days) "))
hrs_at_park_per_day = int(input("How many hours are you spending at the park per day? "))
meals_repeated = int(input("How many times are you going to eat food per day? "))
line_skip_repeated = int(input("How many times are you going to skip the line? "))
additional_parking_cost = int(input("What is the additional cost for parking? "))
hrs_at_parking_lot_per_day = int(input("How many hours, per day, will you park the rental car inside the parking lot for? "))

#Sub Totals (rows)
flight = flight_ticket_cost * num_people
hotel = hotel_perday_cost * num_days
park_tkt = park_ticket_perday_cost*(num_people*hrs_at_park_per_day)
merch = merch_cost * num_people
meals = (meals_cost*num_people)*meals_repeated
vechile = vechile_rent_cost_perday * num_days
line_skips = (line_skips_cost_each_time*num_people)*line_skip_repeated
parking = (parking_perday_cost+additional_parking_cost)*hrs_at_parking_lot_per_day

#Final Result
total = flight + hotel + park_tkt + merch + meals + vechile + line_skips + parking

print("The Flight cost is: $" + str(flight))
print("The Hotel cost is: $" + str(hotel))
print("The cost of going to the park is: $" + str(park_tkt))
print("The Merch cost is: $" + str(merch))
print("The Meals cost is: $" + str(meals))
print("The Vechile cost is: $" + str(vechile))
print("The line skips cost is: $" + str(line_skips))
print("Parking the car will cost: $" + str(parking))
print("The grand total is: $" + str(total))