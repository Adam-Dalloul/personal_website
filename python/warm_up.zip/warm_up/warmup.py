#Challenge 1

variableString = "This is a string"
variableInt = 10
variableFloat = 0.0009

print(variableString)
print(variableInt)
print(variableFloat)

#Challenge 2
userAge = int(input("What is your age? "))

if userAge <= 14 and userAge >= 10:
    print("You are in middle school")
elif userAge <= 18 and userAge >= 15:
    print("You are in high school.")
else:
    print("You are too young or too old for EPS")

#Challenge 3
for i in range (10,21):
    print(i)

#Challenge 4
import random

print(random.randint(0,100))

#Challenge 5
user_input = ""
while user_input != "potato" and user_input != "potatoes":
    user_input = input("What has eyes but can't see? ")
print("Correct!")

#Challenge 6

def num(num1,num2):
    result = num1 - num2
    return result

r1 = num(10,5)
print(r1)