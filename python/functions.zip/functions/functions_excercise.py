# # Review on casting

# num = 7 
# str1 = "Hello"
# num2 = 0.112
# num2 = int(num2)

# num3 = "10"
# print(int(num3)*100)

# num4 = int(input("How many people are going to Disney Land?"))

# Functions

#Example
def hello_world():
    print("Hello World!")

#hello_world()

#Challenge 1
def hello2(name):
    print("Hello, " + name + "!")

hello2("Yash")
user_input = input("What's your name? ")
hello2(user_input)

#Challenge 2
def annoyingGreet(name2):
    for i in range (10):
        print("Hello", name2)

annoyingGreet("Adam")

#Challenge 3
def annoyingGreet2(name3, greetNum):
    for i in range (greetNum):
        print("Hello", name3)

annoyingGreet2("Max", 2)

#Challenge 4
def sumOfNumbers(num1, num2):
    result = num1 + num2
    print(result)

sumOfNumbers(10,20)

#Challenge 5
def square(num3):
    print(num3**2)

square(5)

#Challenge 6
def sumOfSquares(num1, num2):
    square1 = square(num1)
    square2 = square(num2)
    result = sumOfNumbers(square1, square2) 
    return result


sumOfSquares()

#I did not figure this challenge out