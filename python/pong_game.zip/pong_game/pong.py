import tkinter

# Graphic Paramaters
CANVAS_WIDTH = 400
CANVAS_HEIGHT = 500
BALL_SIZE = 25
TIMER_REFRESH = 10
PADDLE_WIDTH = 100
PADDLE_HEIGHT = 20

# Ball movement
y_move = 2
x_move = 2

# Paddle Movement
paddle_speed = 5

# Rabbit Movement
image_y_move = 3
image_x_move = 3

# Game State
game_running = True

def end_game():
    global game_running

    game_running = False
    canvas.create_text(CANVAS_WIDTH/2, CANVAS_HEIGHT/2, text="GAME OVER")

# Move paddle when key is pressed
def move_paddle(event):
    # Which key is pressed
    key_symbol = event.keysym
    print(key_symbol)

    # Where is the paddle now
    pos = canvas.coords(paddle)
    left = pos[0]
    right = pos[2]
    up = pos[1]
    down = pos[3]
    
    #move paddle left
    if key_symbol == "Left" and left > 0:
        canvas.move(paddle,-paddle_speed, 0)
    #move paddle right
    elif key_symbol == "Right" and right <= CANVAS_WIDTH-10:
        canvas.move(paddle,paddle_speed, 0)
    #move paddle up
    elif key_symbol == "Up" and up >= 10:
        canvas.move(paddle, 0, -paddle_speed)
    #move paddle down
    elif key_symbol == "Down" and down <= CANVAS_HEIGHT-8:
        canvas.move(paddle, 0, paddle_speed)

def collision(left, top, right, bottom):
    # Check to see if ball collided with paddle
    overlap_result = canvas.find_overlapping(left, top, right, bottom)

    # Is my paddle in the overlap result?
    # return true if yes, else false
    if paddle in overlap_result:
        return True;
    else:
        return False;    

# Draw/move ball
def draw():
    global y_move
    global x_move        
    #move the ball
    canvas.move(ball1, x_move, y_move)

    # What is the current location of the ball?
    pos = canvas.coords(ball1)
    top_y = pos[1]
    bottom_y = pos[3]
    left_x = pos[0]
    right_x = pos[2]

    # Time to bounce?
    # Did it hit the bottom or top (y value)?
    if top_y <= 0:
        y_move = -y_move
        canvas.itemconfig(ball1, fill="blue")
    elif bottom_y >= CANVAS_HEIGHT-5:
        end_game()
    # Did it hit the top or bottom (x value)?
    elif left_x <= 0 or right_x >= CANVAS_WIDTH-5:
        x_move = -x_move
        canvas.itemconfig(ball1, fill="green")
    
    # Did the ball collide with the paddle? If so bounce off
    if collision(pos[0],pos[1],pos[2],pos[3]):
        y_move = -y_move

def draw_image():
    global image_y_move
    global image_x_move

    canvas.move(rabbit, image_x_move, image_y_move)

    # What is the current location of the rabbit?
    pos = canvas.coords(rabbit)
    top_y = pos[1]
    left = pos[0]
    right = left + rabbit_width
    bottom_y = top_y +rabbit_height
    

    # Time to bounce?
    # Did it hit the bottom or top (y value)?
    if top_y <= 0:
        image_y_move = -image_y_move
    elif bottom_y >= CANVAS_HEIGHT-5:
        end_game()
    # Did it hit the top or bottom (x value)?
    elif left <= 0 or right >= CANVAS_WIDTH-5:
        image_x_move = -image_x_move
            
    # # Did the ball collide with the paddle? If so bounce off
    if collision(left, right, top_y, bottom_y):
        image_y_move = -image_y_move

# Animaiton Timer
def master_timer():
    # Draw/move ball
    draw()
    draw_image()
    # tkinter procecssing
    main.update_idletasks()
    main.update()
    if game_running:
        main.after(TIMER_REFRESH, master_timer)


main = tkinter.Tk()
main.title("Simplified Pong")
# Lock Window Size (block resizing window)
main.resizable(0,0)

# Draw the Canvas
canvas = tkinter.Canvas(main, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bd=0, highlightthickness=0)
canvas.pack()

# Add Rabbit Image
image = tkinter.PhotoImage(file="Images\\Rabbit.gif")
small_image = image.subsample(4,4)
rabbit = canvas.create_image(0,0,anchor=tkinter.NW,image=small_image)
# Get Demensions of my image
rabbit_height = small_image.height()
rabbit_width = small_image.width()

# Add red ball to the Canvas
ball1 = canvas.create_oval(0,0, BALL_SIZE, BALL_SIZE, fill="pink")
# Move ball to starting position, the center of the screen
canvas.move(ball1, CANVAS_WIDTH/2, CANVAS_HEIGHT/2)

# Add Paddle
paddle = canvas.create_rectangle(0,0,PADDLE_WIDTH, PADDLE_HEIGHT, fill="orange")
canvas.move(paddle, CANVAS_WIDTH/2, CANVAS_HEIGHT/1.2)

# Add key bindings
canvas.bind_all("<KeyPress-Right>", move_paddle)
canvas.bind_all("<KeyPress-Left>", move_paddle)
canvas.bind_all("<KeyPress-Up>", move_paddle)
canvas.bind_all("<KeyPress-Down>", move_paddle)

# Call master timer
master_timer()

# Keep the Window up
main.mainloop()
