import random
play = "yes"
firstPlay = input("Do want to play the game (any input to continue/no)? ")
firstPlay = firstPlay.lower()

if firstPlay == "no":
    print("Ok... maybe consider playig my game some other time :(")
    exit()

while play == "yes":
    print("Hello, welcome!")

    print("""You, a vicious warrior are on a journey to find a lost Gem that could save your home city. Along this adventure you must concur beasts and you are about to kill the last monoster to retrieve the Gem...

     HOWEVER, this monoster is no ordinary one, he is the strongest in the vally...
        and there are only a couple ways to defeat him    
        """)

    attackMonosterInput = input("Which way would you like to kill the monoster, (0 or 1)? ")
    while attackMonosterInput >= "2" or attackMonosterInput < "0":
        print("You put the wrong input for how to kill the monoster, make sure your input is 0-1!")
        print("Now.. try again!")
        attackMonosterInput = input("Which way would you like to kill the monoster, (0 or 1)? ")  

    randomNumber = str(random.randint(0,1))

    if attackMonosterInput == randomNumber:
        print("You have decied to kill the monoster by wiping out your sword and slicing the monoster's head off!")
        print("As you take your sword out, the monoster's lighting reflexes slash out the sword and it is now broken.")
        print("You have lost your only weapon of defense and now you try to run away from the monoster out of sheer fear.")
        print("You simply cannot outrun the monoster...")
        print("The monoster catches up with ease and with his huge claws, slashes your body down on the floor.")
        print("As you are on the floor, you pick up a rock beside you and slash the monoster's face!")
        print("The monoster's face starts bleading and he falls to the ground, you have killed the monoster!")
        print("You enter the cave and collect the Gem")
        print("You return to the city and save it!")
    else:
        description = int(input("What is your warrior's age (Between 1-100)? "))
        if description >= 0 and description <= 14:
            print("The monoster recgonizes your young age and spares your life.")
            print("He lets you go but you leave without the Gem.")
            print("You return back to the city without the Gem.")
            print("The city is doomed without the Gem and is eradicated within a couple hours.")
        elif description >= 15 and description <= 22:
            print("The monoster decides you have already lived a long enough life.")
            print("He slashes his muscular hand across your face.")
            print("You fall to the ground.")
            strong = input("What is your strength (H, M, L) (H = High, M = Medium, L = Low)? ")
            if strong == "H" or strong == "h":
                print("You were able to deflect the monoster's slash and you kill him with your insane strength.")
                print("You take the Gem and save the city!")
            elif strong == "M" or strong == "m":
                print("You are not strong enough and the monoster crushes you, you die!")
                print("The city dies.")
            elif strong == "L" or strong == "l":
                print("You are too weak, you die a painful death as the monoster plunges his massive arm into your body.")
                print("The city dies without the Gem.")
            else:
                print("You put the wrong input for your strength level!")
                print("Your strength is brought down to nothing.")
                print("The monoster eats you alive with ease and the city disappears!")              
        elif description >=23 and description <= 100:
            print("The monoster decides that your human flesh is been fully devolped.")
            print("He eats your tasty meat and you die.")
            print("The city then collapses and burns without the Gem")
        else:
            print("You put the wrong input for your warrior's age!")
            print("The monoster assumes that you'r flesh is still new.")
            print("He eats all of your organs!")
            print("The city falls apart and you DIE!")
        
    play = input("Do you want to play again (yes/any input to cancel)? ")
    play = play.lower()
    
print("Ok, bye, have fun playing next time!")   