from imaplib import Int2AP


import random

int1 = 10
float1 = 0.004

#Cast an integer as a float using float() then orint it out 
float2 = float(int1)
print(float2)

#Cast a float to integer using int() then print it out
float2 = int(float1)
print(float2)

float1 = 0.6666
int2= int(float1)
print(int2)

#do some math + - * /
#mod % REMAINDER
random_day = random.radint(0,9)

if random_day % 7 == 0:
    print("Monday!")
elif random_day %7 == 1:
    print("Tuesday!")

#Or Logic
age = 101
if age < 0 or age > 100:
    print("Invalid age")