import random
#Printing out the intro for the game
play_game = "yes"

while play_game == "yes":
    print("""
    Welcome to the dragon realms! Choose a cave. One will lead to fortune, but the other will lead to..

    DOOOOM!!

    """)

    #Ask player which cave to enter
    cave = input("Which cave would you like to enter (0 or 1)? ")
    
    #Random number between 0 and 1
    friendly_cave = str((random.randint(0,1)))

    if cave == friendly_cave:
        print("You get some gold!")
    else:
        #chance to survive, what is yoru age?
        age = int(input("How old are you? "))
        if age >= 0 and age <= 18:
            print("You are tasty, i eat you and you die!")
        elif age >= 19 and age <= 80:
            print("The dragon feels sorry and you don't die! ")
        elif age > 80:
            print("The dragon decides to eat you and you die")
        else:
            print("Invalid age!, for that, you still die!")
    play_game = input("Do you want to play again? ")
    play_game = play_game.lower()

print("Goodbye!")
#Print out the result
#   If player chose 0, then fortune!
# if cave == "0":
#     print("You have been rewarded money and won the game, congrats!")
# #Else if player chose 1, go back home
# elif cave == "1":
#     print("You have decided to go back home, BYE!")
# #Else if player chose 2, then doom!
# elif cave == "2":
#     print("The dragon has eaten you alive and you have died, YOU LOST!")
# #catch invalid inputs
# else:
#     print("Invalid input, follow the instructions please :)")