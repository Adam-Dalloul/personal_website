# print("While loop - 20 to 30")
# counter1 = 20
# while counter1 <= 30:
#     print(counter1)
#     counter1 += 1
#     print("Done")

# print("While loop - count 10 to 0")
# counter2 = 10
# while counter2 >= 0:
#     print(counter2)
#     counter2 -= 1
#     print("Done")


# print("While loop - count 0 to 10 even numbers only")
# counter3 = 0
# while counter3 <= 10:
#     print(counter3)
#     counter3 += 2
#     print("Done")


# print("For Loops 0 to 10")
# for x in range (11):
#     print(x)

# print("For Loops 5 to 10")
# for x in range (5,11):
#     print(x)

# print("For loops - 0 to 10, odd numbers only")
# for x in range (1,11,2):
#     print(x)

# print("This is my game")
# play = input("Do you want to paly the game (yes/no)?: ")
# play = play.lower()

# while play or playAgain == "yes":
#     print("Ok, Hi!")
#     print("This is the game!")
#     playAgain = input("Do you want to play again(yes/no)? ")
#     playAgain = playAgain.lower()
# else:---------------------------------------------------------------
#     print("Ok bye!")
    
#Game Loop corect
print("Welcome to my game")
play_game = "yes"

while play_game == "yes":
    print("whooo i'm playing the game!")
    play_game = input("Do you want to paly the game again (yes/no)? ")
    play_game = play_game.lower()

print("Goodbye!")